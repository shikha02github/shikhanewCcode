
#include<stdio.h>
#include<stdlib.h>

int row;
void Array_1d(int *a);
void Array_2d(int (*b)[3]);
int main()
{
 	  int choice ;
            	
		           int *a;
                            int (*b)[3];                     

           while(1){

		   printf("0:EXIT \n\n1: 1D ARRAY\n\n 2::2D ARRAY\n\n");
		   
		   printf("enter above choice\n");
		   
		   scanf("%d",&choice);
                    
		   switch(choice)
	         	   {
				     case 0:
					       exit(0);
					   
					         break;
				     case 1:
					        Array_1d(a);
			
					         break;
				  case 2:
				            Array_2d(b);
				            
				            break;
				
					       default :
				
					        printf("wrong choice\n");
				
					        break;
			   }

			   
	   }
	
        
}
void Array_1d(int *a)
{       int n;
	printf("enter the size of array is\n");
	  	
	  	scanf("%d",&n);
	 	
	 	                                
		 a=(int *)malloc(sizeof(int)*n);
                                        
		
		printf("enter the element int array\n");
		
		for(int i=0;i<n;i++)
		{
		
			scanf("%d",&a[i]);
		
		    
		}
	
		printf("ARRAY IS \n");
		
		for(int i=0;i<n;i++)
		{
			
			
		printf("%d\n",a[i]);
		
		    
		}

}

void Array_2d(int (*a) [3])
{           
	   
 		int row;
	
           printf("enter the size of row\n");
          
           scanf("%d",&row);
             
           
           
           a=(int (*)[3])malloc(row*sizeof(int)*3);
           
           printf("enter array element");
            
            for(int i=0;i<row;i++)
            
            {
               
                for(int j=0;j<3;j++)
               
                {
                 
                    scanf("%d",&a[i][j]);
                
                    
                }
           
            }
           
            printf("2d array element is \n");
           
           for(int i=0;i<row;i++)
            {
                
                for(int j=0;j<3;j++)
                
                {
                
                    printf("%d\t\t",a[i][j]);
                
                    
                }
                
                printf("\n");
            }
           
}



