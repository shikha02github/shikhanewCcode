#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Structure definition
struct Employee {
    int empid;
    char name[50];
    float salary;
    int year_of_joining;
};

// Function to calculate service for each employee element in the array
int calculate_service(struct Employee *emp, int current_year) {
    return current_year - emp->year_of_joining;
}

// Function to find the total, average, max, min salary and employees with max, min service
void process_employees(struct Employee *emp, int n, int current_year) {
    int i, total_service = 0, min_service = 10000, max_service = 0;
    float total_salary = 0, min_salary = 100000, max_salary = 0;
    struct Employee *min_service_emp = NULL, *max_service_emp = NULL;

    for (i = 0; i < n; i++) {
        int service = calculate_service(&emp[i], current_year);
        total_service += service;
        total_salary += emp[i].salary;

        if (service < min_service) {
            min_service = service;
            min_service_emp = &emp[i];
        }

        if (service > max_service) {
            max_service = service;
            max_service_emp = &emp[i];
        }

        if (emp[i].salary < min_salary) {
            min_salary = emp[i].salary;
        }

        if (emp[i].salary > max_salary) {
            max_salary = emp[i].salary;
        }
    }

    printf("Total salary: %.2f\n", total_salary);
    printf("Average salary: %.2f\n", total_salary / n);
    printf("Maximum salary: %.2f\n", max_salary);
    printf("Minimum salary: %.2f\n", min_salary);
    printf("Employee with maximum service: %s, service: %d\n", max_service_emp->name, max_service);
    printf("Employee with minimum service: %s, service: %d\n", min_service_emp->name, min_service);
}

int main() {
    int n, current_year;
    printf("Enter the current year: ");
    scanf("%d", &current_year);

    printf("Enter the number of employees: ");
    scanf("%d", &n);

    struct Employee *emp = (struct Employee *)malloc(n * sizeof(struct Employee));

    for (int i = 0; i < n; i++) {
        printf("Enter employee %d details:\n", i + 1);
        printf("Employee ID: ");
        scanf("%d", &emp[i].empid);
        printf("Employee Name: ");
        scanf("%s", emp[i].name);
        printf("Salary: ");
        scanf("%f", &emp[i].salary);
        printf("Year of joining: ");
        scanf("%d", &emp[i].year_of_joining);
    }

    process_employees(emp, n, current_year);

    free(emp);

    return 0;
}
