#include<stdio.h>
#include<stdlib.h>
struct node {
	int data;
	struct node *next;
};
void insertAtPos(struct node **, int, int);
void insertAtEnd(struct node **, int );
void insertAtBeg(struct node **, int );
void display(struct node *);
void revDisplay(struct node *);
void revLL(struct node **);
void sortLL(struct node *);
int main(){
	struct node *head=NULL;
	int choice, ele, val;
	while(1){
	printf("enter choice\n");
	printf("1- insertAtEnd, 2- display, 4-insertAtBeg 3- exit\n");
	printf("5- insertAtPos, 6- revDisplay 7- revLL 8 sortLL\n");
	scanf("%d", &choice);
	switch(choice){
		case 1:
			printf("enter an int ele\n");
			scanf("%d", &ele);
			insertAtEnd(&head, ele);
			break;
		case 2:
			display(head);
			printf("\n");
			break;
		
		case 4:
			printf("enter an int ele\n");
			scanf("%d", &ele);
			insertAtBeg(&head, ele);
			break;
		case 5:
			printf("enter an int ele and pos\n");
			scanf("%d %d", &ele, &val);
			insertAtPos(&head, ele, val);
			break;
		case 6:
			revDisplay(head);
			printf("\n");
			break;
		case 7:
			revLL(&head);
			break;
		case 8:
			sortLL(head);
			break;
		case 3:
			exit(1);

		default:
			printf("enter a valid choice\n");
			break;
	}
	}
}

void sortLL(struct node *p)
{
    int swapflag, i;
    struct node *t1;
    struct node *x = NULL;
    /* Checking for empty list */
    if (p == NULL || p->next == NULL)
        return;
    do
    {
        swapflag = 0;
        t1 = p;
        while (t1->next != x)
        {
            if (t1->data > t1->next->data)
            {
		int temp = t1->data;
		t1->data = t1->next->data;
		t1->next->data=temp;
                swapflag = 1;
            }
           t1 = t1->next;
        }
        x = t1;
    }
    while (swapflag);
}
void revLL ( struct node **p )
{
        struct node *t1, *t2, *t3 ;
	if(*p==NULL || (*p)->next==NULL){
		return;
	}
        t1 = *p ;
        t2 = NULL ;
        /* traverse the entire linked list */
        while ( t1 != NULL )
        {
                t3 = t2 ;
                t2 = t1 ;
                t1 = t1 -> next ;
                t2 -> next = t3 ;
        }

        *p = t2 ;
}


void revDisplay(struct node *p){
	if(p==NULL){
		return ;
	}
	revDisplay(p->next);
	printf("%d-->", p->data);

}

void insertAtPos(struct node **p, int ele, int pos){
	struct node *temp;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=ele;
	temp->next=NULL;
	if(pos==1){
		insertAtBeg(p, ele);
		return;
	}
	int i=1;
	struct node *t1, *t2;
	t1=*p;
	//t2=NULL;
	while(i<pos-1){
	//	t2=t1;
		t1=t1->next;	
		i++;
	}

	temp->next=t1->next;
	t1->next=temp;
}
void insertAtBeg(struct node **p, int ele){
	struct node *temp;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=ele;
	temp->next=NULL;

	if(*p==NULL){
		*p=temp;
	}else {
		temp->next=*p;
		*p=temp;
	}

}
void display(struct node *q){
	while(q!=NULL){
		printf("--> %d", q->data);
		q=q->next;
	}
}

void insertAtEnd(struct node **p, int ele){
	struct node *temp, *t1;
	t1=*p;
	temp=(struct node *)malloc(sizeof(struct node));
	temp->data=ele;
	temp->next=NULL;

	if(*p==NULL){
		*p=temp;
		// this node is going to be very first node
	}else {
		while(t1->next!=NULL){
			t1=t1->next;
		}
		// you have an existing link list
		t1->next=temp;
	}
}






