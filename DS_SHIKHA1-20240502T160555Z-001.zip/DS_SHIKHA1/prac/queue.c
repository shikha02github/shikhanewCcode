#include<stdio.h>
#include<stdlib.h>
void enqueue(int *,int *,int *, int); // para (arr, front, rear , ele)
int dequeue(int *,int *, int *);
void display(int *);

#define SIZE 5

int main(){
	int front=-1, rear=-1;
	int arr[SIZE];
	int choice, ele, ret;
	for(int i=0; i<SIZE; i++)
		arr[i]=-99;
	while(1){
	printf("1-> enqueue 2->dequeue 3->display 4->exit");
	scanf("%d", &choice);

	switch(choice){
		case 1:
			printf("enter ele\n");
			scanf("%d", &ele);
			enqueue(arr,&front,&rear,ele);
			break;
		case 2:
			ret=dequeue(arr,&front, &rear);
			if(ret!=-9){
			printf("popped item=%d\n", ret);
			}
			break;
		case 3:
			display(arr);
			break;
		case 4:
			exit(0);
	}
	}
	return 0;
}			

void enqueue(int *a, int *f, int *r, int ele){

	if(*r==SIZE-1){
		printf("queue full");
		return;
	}

	*r=*r+1; 
	a[*r]=ele;

	if(*f==-1){
		*f=0;
	}
}

int dequeue(int *a, int *f, int *r){
	if(*f==-1){
		printf("no items- queue empty\n");
		return -9;
	}

	int temp=a[*f];
	a[*f]=-99;
	
	if(*f==*r){
		*f=-1; *r=-1;
	}else {
		*f=*f+1;
	}
	
	return temp;
}
	
void display(int *a){
	printf("Queue--");
	for(int i=0; i<SIZE; i++){
		printf("%d ", a[i]);
	}
	printf("\n");
}












