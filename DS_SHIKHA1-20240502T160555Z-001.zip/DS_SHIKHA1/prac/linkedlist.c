#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *next;
};

struct node *head;
void insertAtEnd(int);


int main()
{
	head=NULL;
	int ele,pos;
	while(1)
	{
		printf("insert the element at end\n");
		scanf("%d",&ele);
	}

void insertAtEnd(int ele)
{
	struct node *temp;
	struct node *t1;
	t1=head;

	temp=(struct node*)malloc(sizeof(struct node));
	temp->data=ele;
	temp->next=NULL;

	if(head==NULL)
	{
		head=temp;
	}
	else
	{
		while(t1->next!=NULL)
		{
			t1=t1->next;
		}
		t1->next=temp;
	}
}

}
