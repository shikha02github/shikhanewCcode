 #include<stdio.h>

int main()
{
	int a[5]={10,20,30,40,50};
	int key,flag=0,high=4,low=0,mid;
	printf("enetr the key\n");
	
		scanf("%d",&key);

	while(low<=high)
	{
		mid=(low+high)/2;
		if(key==a[mid])
		{
			printf("element found\n");
		

			flag=1;
			break;
		}
		else if(key<a[mid])
		{
		
			high=mid-1;

		
		}
		
		else if(key>a[mid])
		{
		
			low=mid+1;
		}
	}		

		
	

	if(flag==1)
	{
		printf("key is found\n");
	}
	else
	{
		printf("key not found\n");
	}

}
