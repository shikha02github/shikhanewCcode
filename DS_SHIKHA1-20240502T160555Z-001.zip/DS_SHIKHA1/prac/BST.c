#include<stdio.h>
#include<stdlib.h>
struct node
{
	struct node *left;
	int data;
	struct node *right;
};

void insert(struct node **,int);
void preorder(struct node *);
void inorder(struct node *);
void postorder(struct node *);
void deleteNode(struct node *);

int main()
{
	struct node *root=NULL;
	int choice,ele;

	while(1)
	{
		printf("1-insert\n\n2-preorder\n3-inorder\n4-postorder\n5-delete\n6-exit\n");
		printf("enetr the choioce\n");
		scanf("%d",&choice);

		switch(choice)
		{
			case 1:
				printf("enetr the element\n");
				scanf("%d\n",&ele);
				insert(&root,ele);
				break;

			case 2:
				printf("tree preorder\n");
				preorder(root);
				break;

			case 3:
				printf("tree inoreder\n");
				inorder(root);
				break;

			case 4:
				printf("tree postorder\n");
				postorder(root);
				break;

			case 5:
				printf("delete leaf node\n");
				deleteNode(root);
				break;
			case 6:
				exit(0);

			default:
				printf("wrong choice\n");
		}
	}
	return 0;
}
void insert(struct node **p,int ele)
{
        if((*p)==NULL)
        {
                *p=(struct node *)malloc(sizeof(struct node));
                (*p)->data=ele;
                (*p)->left=NULL;
                (*p)->right=NULL;
        }
        else
        {
                if(ele<(*p)->data)
                {
                        insert(&((*p)->left),ele);
                }
                else
                {
                        insert(&((*p)->right),ele);
                }
        }
}

void preorder(struct node *p)
{
	if(p!=NULL)
	{
		printf("%d\n",p->data);
		preorder(p->left);
		preorder(p->right);
	}
}

void inorder(struct node *p)
{
	if(p!=NULL)
	{
		inorder(p->left);
		printf("%d\n",p->data);
		inorder(p->right);
	}
}

void postorder(struct node *p)
{
	if(p!=NULL)
	{
		postorder(p->left);
		postorder(p->right);
		printf("%d\n",p->data);
	}
}

void deleteNode(struct node *p)
{
	if(root==NULL)
	{
		return;
	}
	while
	{
		if(root->left==NULL && root->right==NULL)
		{
			if(root->data=ele)
				printf("root deleted\n");
			


