#include<stdio.h>
#include<stdlib.h>

struct node
{
	int data;
	struct node*next;
};

struct node *list,*temp,*curr;
struct node*list3=NULL;
struct node*list1=NULL;
struct node*list2=NULL;


struct node *insert(struct node *list,int ele)
{
	temp=(struct node*)malloc(sizeof(struct node*));
	temp->data=ele;
	temp->next=NULL;
	if(list==NULL)
		list=temp;
	else
	{
		curr=list;
		while(curr->next!=NULL)
			curr=curr->next;
			curr->next=temp;
	}
	return list;
}


void forward(struct node *list)
{
	curr=list;
	while(curr!=NULL)
	{
		printf("%d\t",curr->data);
		curr=curr->next;
	}
}


struct node*merge(struct node* list3,struct node*list1,struct node *list2)
{
	struct node *c1,*c2;
	c1=list1;
	c2=list2;

	while(c1!=NULL && c2!=NULL)
	{
		if(c1->data>c2->data)
		{
			list3=insert(list3,c1->data);
			c1=c1->next;
		}
		else if(c2->data<c1->data)
		{
			list3=insert(list3,c2->data);
			c2=c2->next;
		}
		else
		{
			list3=insert(list3,c1->data);
			c1=c1->next;
			c2=c2->next;
		}
	}

	while(c1!=NULL)
	{
		list3=insert(list3,c1->data);
		c1=c1->next;
	}
	while(c2!=NULL)
	{
		list3=insert(list3,c2->data);
		c2=c2->next;
	}
	return list3;
}


int main()
{
	int element,choice;
	printf("1-enetr element of list1\n2-enetr element of list2\n3-print list\n4-exit\n");
	printf("enetr the choice\n");
	scanf("%d",&choice);



	while(1)
	{
		int n,a[5];
		printf("enetr the no of element in array\n");
		scanf("%d",&n);
		printf ("the array element \n");
	       for(int i=0;i<n;i++)
	       {
		scanf("%d",&a[i]);
	       }		
		switch(choice)
		{
			case 1:
				printf("enetr the element in list1\n");
				scanf("%d",&element);
				list1=insert(list1,element);
				break;
			case 2:
				printf("enetr the element of list2\n");
				scanf("%d",&element);
				list2=insert(list2,element);
				break;

			case 3:
				printf("insert list1\n");
				forward(list1);
				printf("insert list2\n");
				forward(list2);
				printf("merged two list list1 and list 2\n");
				list3=merge(list3,list1,list2);
				break;
			case 4:
				exit(1);

			default:
				printf("wrong choice\n");
		}
	}
}



