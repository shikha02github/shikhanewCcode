#include<stdio.h>
struct node
{
	int data;
	struct node *next;
};

struct node *head;
void reverse()
{
	struct node *temp,*prev,next,current;
	temp=head;
	prev=NULL;
	while(temp!=NULL)
	{
		next=current->next;
		current->next=prev;
		current=next;
	}
	head=prev;
}
