#include<stdio.h>
#include<string.h>
#define MAX 50
int stack[MAX];
char post[MAX];

int top =-1;

void pushstack(int temp);
void evaluate(char c);   //calacutation

int main()
{
	 int i,l;
	 printf("insert postfix notation");
	 scanf("%s", post);
	 l=strlen(post);
	 for(i=0;i<l;i++)
	 {
		 if(post[i]>='0' && post[i]<='9')
		 {
			 pushstack(i);
		 }
		 if(post[i]=='+' || post[i]=='-' || post[i]=='*' || post[i]=='/' || post[i]=='^')
		{
			evaluate(post[i]);
		}
	 }
	 printf("\n\t Result:%d\n",stack[top]);
	 return 0;
}

void pushstack(int temp)
	{
	top++;
	stack[top]=(int)(post[temp]-48);
	}


void evaluate(char c)
{
	int a,b,ans;
	a=stack[top];
	stack[top]='\0';
	top--;

	b=stack[top];
	stack[top]='\0';
	top--;

	switch(c)
	{
		case '+':
		ans=b+a;
		break;

		case '-':
		ans=a-b;
		break;

		case '*':
                    ans=a*b;
		break;

		case '/' :
                  ans =a/b;
		  break;

		case '^' :
		  ans=a^b;
		  break;

		default :
		  ans=0;
}
         top++;
         stack[top]=ans;
}

