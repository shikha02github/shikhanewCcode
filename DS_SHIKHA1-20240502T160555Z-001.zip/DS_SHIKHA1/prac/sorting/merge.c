#include<stdio.h>
#include<stdlib.h>
void mergesort(int[],int,int);
void merge(int[],int,int,int);

void main()
{
   
    int arr[10]={11,2,9,13,57,25,17,1,90,3};
    int i;
    printf("merge sort\n");
    printf("array before sorting\n");
    for(i=0;i<10;i++)
        printf("%d \n",arr[i]);
    mergesort(arr,0,9);
    printf("after sorting the array is\n");
    for(i=0;i<10;i++)
    {
        printf("%d \n",arr[i]);
    }
            //return 0;

}

void mergesort(int arr[],int lower,int upper)
{
    int mid;
    if(lower<upper)
    {
        mid=(lower+upper)/2;
        mergesort(arr,lower,mid);
        mergesort(arr,mid+1,upper);
        merge(arr,lower,mid,upper);
    }
}

void merge(int arr[],int lower,int mid,int upper)
{
    int size,*b,first,second,index,i;
    size=upper-lower+1;
    b=(int*)malloc(size*sizeof(int));

    first=lower;
    second=mid+1;
    index=0;

    while(first<=mid && second<=upper)
    {
        if(arr[first]<=arr[second])
        {
            b[index]=arr[first];
            first++;
            index++;
        }
        else{
            b[index]=arr[second];
            second++;
            index++;
        }
    }

    while(first<=mid)
    {
        b[index]=arr[first];
        index++;
        first++;
    }

    while(second<=upper)
    {
        b[index]=arr[second];
        index++;
        second++;
    }
    index=0;

    for(i=lower;i<=upper;i++)
    {
        arr[i]=b[index];
        index++;

    }
    free(b);
}
