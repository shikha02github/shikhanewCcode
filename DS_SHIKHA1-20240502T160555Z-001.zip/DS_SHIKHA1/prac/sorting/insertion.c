//insertionsort
#include<stdio.h>
#include<stdlib.h>
int main()
{
int i,j,a[10],temp,n;
//size array
printf("enter the array size:\n");
scanf("%d",&n);
//reading element into array
printf("enter the element into a array\n");
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
// print array element before sorting
    printf("enter value before sorting");
    for(i=0;i<n;i++)
    {
        printf("%d\t",a[i]);
    }

//logic 
for(i=1;i<n;i++)
{
	int temp=a[i];
	j=i-1;
	while(a[j]>temp && j>=0)
	{
		a[j+1]=a[j];
		j--;
	}
	a[j+1]=temp;
}
//print element after sorting
printf("\nafter sorting\n");
    for(i=0;i<n;i++)
    {
        printf("%d\t",a[i]);
    }
return 0 ;
}
