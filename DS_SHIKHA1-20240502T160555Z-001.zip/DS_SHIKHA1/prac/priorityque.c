#include<stdio.h>
#include<stdio.h>

//#priority queue

struct prique
{
	int ele;
	unsigned int pri;
};

void enque(int *,int *,int *,int);//parameter (arr,front,rear,ele)
int deque(int *,int *,int *);
void display(int *);

#define SIZE 5


int main()
{
	int front=-1, rear=-1;
	struct prique arr[SIZE];
	int choice,ele,ret;

	for(int i=0;i<SIZE;i++)
		arr[i]=-99;

	while(1)
	{
		printf("1->enque 2->deque 3->display 4->exit");
		scanf("%d",&choice);
		
		switch(choice)
		{
			case 1:
				printf("enetr element\n");
				scanf("%d",&ele);
				enque(arr,&front,&rear,ele);
				break;

			case 2:
				ret=deque(arr,&front,&rear);
				if(ret!=-9)
				{
					printf("popped item=%d\n",ret);
				}
				break;

			case 3:
				display(arr);
				break;

			case 4:
				exit(0);
		}
	}
	return 0;
}


void enque(int *a,int *f,int *r,int ele)
{
	if((*r=SIZE-1 && *f==0)||(*r+1)==*f)
	{
		printf("que is full\n");
		return;
	}
	if(*r==SIZE-1 && *f!=0)
	{
		*r=0;
	}
	else
	{
		*r=*r+1;
	}
	a[*r]=ele;

	if(*f==-1)
	{
		*f=0;
	}
}


int deque(int *a,int *f,int *r)
{
	if(*f==-1)
	{
		printf("no item in queue\n");
		return -9;
	}

	int temp=a[*f];
	a[*f]=-99;

	if(*f==SIZE-1 && *r==SIZE-1)
	{
		*f=0;
	}
	else
	{
		if(*f==*r)
		{
			*f=-1,*r=-1;
		}
		else
		{
			*f=*f+1;
		}
	}
	return temp;
}


void display(int *a)
{
	printf("que");
	for(int i=0;i<SIZE;i++)
	{
		printf("%d",a[i]);
	}
	printf("\n");
}


	
