#include<stdio.h>
#include<stdlib.h>
   
void quicksort (int[],int,int);
int partition(int[],int,int);
void swap(int[],int,int);
void display(int[],int);


int main()
{
	int i,n;
	printf("enetr the number of element in array\n");
	scanf("%d",&n);
	printf("enetr the array element in array\n");
	int a[n];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("\n=================print unsorted array\n");
	display(a,n);

	quicksort(a,0,(n-1));
	printf("\n===========print the sorted array\n");
	display(a,n);

	return 0;
}
void quicksort(int a[],int f,int l)
{
	int pivot;
	if(f>=l)
	{
		return;
	}
	pivot=partition(a,f,l);
	quicksort(a,f,(pivot-1));
	quicksort(a,(pivot+1),l);
}

int partition(int a[],int f,int l)
{
	int pivot,l_side,r_side;
	pivot=f;
	l_side=f+1;
	r_side=l;


	while(l_side<=r_side)
	{
		while((a[l_side]<a[pivot]) && (l_side <=r_side))
		{
			l_side++;
		}
		if(l_side>r_side)
		{
			break;
		}
		while((a[r_side]>a[pivot])&&(l_side<=r_side))
		{
			r_side--;
		}

		if(l_side>r_side)
		{
			break;
		}
		swap(a,l_side,r_side);
	}

	swap(a,pivot,r_side);
	return r_side;
}


void swap(int a[],int l,int r)
{
	int temp;
	temp=a[l];
	a[l]=a[r];
	a[r]=temp;
}


void display(int a[],int l)
{
	int i;
	for(i=0;i<l;i++)
	{
		printf("%d\t",a[i]);
	}
	printf("\n");
}



