#include<stdio.h>
#include<stdlib.h>
void enque(int*,int*,int*,int);//para (arr,front,rear,ele)
int deque(int*,int*,int*);
void display(int *);
#define size 5
int main()
{
	int front=-1,rear=-1;
	int arr[size],ele,choice,ret;

	for(int i=0;i<size;i++)
	{
		arr[i]=-99;
		while(1)
		{
			printf("1-enque 2-deque 3-display 4-exit");
			scanf("%d",&choice);
		
			switch(choice)
			{
				case 1:
					printf("enetr ele\n");
					scanf("%d",&ele);
					enque(arr,&front,&rear,ele);
					break;

				case 2:
					ret=deque(arr,&front,&rear);
					if(ret!=-9)
					{
					printf("popped itme=%d\n",ret);
					}
					break;


				case 3:
					display(arr);
					break;

				case 4:
					exit(0);
			}

		}
		return 0;
}
}
void enque(int *a,int *f,int *r,int ele)
{
	if(*r=size-1)
	{
		printf("enque is full");
		return;
	}
	*r=*r+1;
	a[*r]=ele;

	if(*f==-1)
	{
		*f=0;
	}
}

int deque(int *a,int *f,int *r)
{
	if(*f==-1)
	{
		printf("queue is empty\n");
		return -9;
	}
	int temp=a[*f];
	a[*f]=-99;
	if(*f==*r)
	{
		*f=-1;
		*r=-1;
	}
	else
	{
		*f=*f+1;
	}
	return temp;
}

void display(int *a)
{
	printf("queue");
	for(int i=0;i<size;i++)
	{
		printf("%d-->",a[i]);
	}
	printf("\n");


	
}
