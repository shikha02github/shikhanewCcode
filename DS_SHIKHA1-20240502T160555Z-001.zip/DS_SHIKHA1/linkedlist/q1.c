#include<stdio.h>
#include<stdlib.h>
struct node{
	int data;
	struct node *next;

};
void insertatend(int ele);
void insertatbeg(int ele);
void display();
void deletefrombeg();
void deletefromend();
void listnodeCount();
void deleteElement();
void reverseDisplay();
void freeallNode();
void reverseList();
void sortList();


struct node *head;
int main()

{
	int ele,pos,choice;
	head = NULL;
	while(1)
	{
		printf("\n\nEnter your choice\n \n\n1->insert at begin\n2->insert at end \n3->display\n4->delete from beg\n5->delete from end\n6->listnodeCount\n7->deleteElement\n8->reverseDisplay\n9->freeallNode\n10->reverseList\n11->sortList\n0-> exit\n\n");
	        scanf("%d",&choice);
	
		switch(choice)
		{
			case 1:
				printf("enter element\n");
				scanf("%d",&ele);
				insertatbeg(ele);
				break;
			case 2:
				printf("enter ele\n");
				scanf("%d",&ele);
				insertatend(ele);
				break;
			case 3:
				display();
				break;
			case 4:
				deletefrombeg();
				break;
			
			case 5:
				deletefromend();
				break;
			case 6:
				listnodeCount();
				break;

			case 7:
				deleteElement();
				break;

			case 8:
				reverseDisplay();
				break;
			case 9:
				freeallNode();
				break;

			case 10:
				reverseList();
				break;
			case 11:
				sortList();
				break;

			case 0:
				exit(0);
			default:
				printf("wrong choice:\n");
				break;
			}
				
		
		}

}
void insertatend(int ele)
{
	struct node *temp;
	struct node *t1;
	t1=head;

	temp=(struct node *)malloc(sizeof(struct node));
	temp->data = ele;
	temp->next= NULL;

	if(head==NULL)
	{
		head = temp;
	}
	else
	{
		while(t1->next!=NULL)
		{
			t1=t1->next;
		}
		t1->next = temp;
	}

}
void insertatbeg(int ele)
{
	struct node *temp;
	temp =(struct node *)malloc(sizeof(struct node));
	temp->data=ele;
	temp->next=NULL;
	if(head==NULL)
	{
		head=temp;
	}
	else
	{
		temp->next=head;
		head = temp;	
	
	}


}

void display()
{
	struct node *t1=head;
	if(head==NULL){
	printf("Linked list empty\n");
	}
	else
	{while(t1!=NULL)
	{
		printf("-> %d",t1->data);
		t1= t1->next;

	}
	}

}
void deletefrombeg()
{
	struct node *t1;
	t1=head;
	head = t1->next;
	free(t1);

}
void deletefromend()
{
	struct node *t1,*t2;
	t1=head;
	if(head->next==NULL){
	 head=NULL;
	}
	while(t1->next!=NULL){
		t2=t1;
		t1=t1->next;
	}
	free(t1);
	t2->next=NULL;

}


void listnodeCount()
{
	struct node *t1=head;
	int count=0;
	while(t1!=NULL)
	{
		t1=t1->next;
		count++;
	}
	printf("count =%d",count);
}

void deleteElement()
{
	struct node *t1=head;
	int pos,count=1;
	struct node *temp;
	printf("enetr the position\n");
	scanf("%d",&pos);

	while(t1!=NULL)
	{
		count++;
		temp=t1;
		t1=t1->next;
		if(pos==count)
		{
			temp->next=t1->next;
		}
	}
	free(t1);
}



void reverseDisplay()
{   struct node *t1=head;    
    if(t1==NULL)
       return;
	
	reverseDisplay();
	printf("%d",t1->data);
}

void freeallNode()
{

	struct node *t1=head;
	while(t1->next!=NULL)
	{
	deletefromend();
	}
	deletefromend();
}

void reverseList()
{
	struct node *prev;
	struct node *next;
	struct node *current;
	current=head;
	prev=NULL;
	while(current!=NULL)
	{
		next=current->next;
		current->next=prev;
		prev=current;
		current=next;
	}
	head=prev;

}

void sortList()
{   
   struct node *t1, *t2;
  int temp;


  t1 = head;


  while (t1->next != NULL)
	{
	  t2 = t1->next;
	  while (t2 != NULL)
		{

		  if (t1->data > t2->data)
			{
			  temp = t1->data;
			  t1->data = t2->data;
			  t2->data = temp;

			}
		  t2 = t2->next;
		}
	  t1 = t1->next;


	}
  
}




