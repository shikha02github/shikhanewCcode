
/*Q1. Write a C/C++ program that declares an array of length N
containing integers between 1 and N. Implement menu driven
program using switch case for below mentioned functionalities.
(a) insert element at index
(b) delete element at index
(c) find min val
(d) find max val
(e) display array element
(f) reverse display array element
(g) search element in array
(h) array element count
(i) avg of all array element
(j) determine if array contains any duplicates.
(k) reverse array element*/

//header file
#include<stdio.h>
#include<stdlib.h>
//function declaration
void add(int []);
void delete(int []);
void insert(int []);
int minimum(int *);
int maximum(int *);
void display(int *);
void reversed_array(int *a);
int search(int *a);
void duplicate(int *a);
int size;//size globally decalred
int *p;
//
int main()
{
	p=(int *)malloc(sizeof(int)*size);//dynamic memory alloacted
	if(p==NULL)
	{
	printf("invalid memory allocations\n");
	}
	int choice,a;
	while(1)
	{
		printf("--------\n");
		printf("1:add element\n 2:delete element\n 3:insert data at specific position\n 4:min value\n 5:max value\n 6:display the array element\n 7:reversed array\n 8:search element\n 9:duplicate element\n 10:exit\n");
		printf("enetr the choice\n");
		scanf("%d",&choice);

		switch(choice)
		{
			case 1:
				add(p);
				break;
			case 2:
				delete(p);
				break;
			case 3:
				insert(p);
				break;
			case 4:
				printf("%d\n",minimum(p));
				break;
			case 5:
				printf("%d\n",maximum(p));
				break;

			case 6:
				display(p);
				break;
			case 7:
				reversed_array(p);
				break;
			case 8:
				search(p);
				break;
			case 9:
				duplicate(p);
				break;
			case 10:
				exit(0);
				break;
			default:
				printf("wrong choice\n");

		}
	}
	return 0;
}


//add element in array===========//
void add(int a[])
{
	printf("enetr the size of array\n");
	scanf("%d",&size);
	printf("the original array element is:\n");
	for(int i=0;i<size;i++)
	{
		scanf("%d",&a[i]);
	}
}
//display all element in array======//
void display(int *a)
{
	for(int i=0;i<size;i++)
	{
		printf("%d\n",a[i]);
	}
}

//reversed the array element
void reversed_array(int *a)
{
    int temp,i,start=0,end=size-1;
    int arr[5]={10,20,30,40,50};
    for(int i=0;i<size;i++)
    {
        temp=arr[start];
        a[start]=arr[end];
        arr[end]=temp;
    	start++;
	end--;
    }
}

//delete array element 
void delete(int a[])
{
	int pos,i;
	printf("eneter which position where you want to delete\n");
	scanf("%d",&pos);

	if(pos<=0||pos>size)
	{
		printf("invalid position\n");
	}
	else
	{
		for(i=pos-1;i<size-1;i++)
		{
			a[i]=a[i+1];
		}
		size--;
	}
	printf("========================print array\n");
	for(i=0;i<size;i++)
	{
		printf("%d",a[i]);
	}

}



//insert element in arrrayy========
void insert(int a[])
{
	int num,pos,i;
	printf("eneter the num &position where you want to store\n");
	scanf("%d%d",&pos,&num);

	if(pos<=0||pos>size-1)
	{
		printf("invalid position\n");
	}
	else
	{
		for(i=size-1;i>=pos-1;i--)
		{
			a[i+1]=a[i];
		}
		a[pos-1]=num;
		size++;
	}

	printf("after insertint array element is \n");
	for(i=0;i<size;i++)
	{
		printf("%d",a[i]);
	}
}

//find the minimum element in array
int minimum(int *a)
{
	int min,i;
	min=a[0];
	for(i=0;i<size;i++)
	{
		if(min>a[i])
		{
			min=a[i];
		}
	}
	printf("minimum value of array\n");
	return min;
}

//find the maximum element in array

int maximum(int *a)
{
	int max,i;
	max=a[0];

	for(i=0;i<size;i++)
	{
		if(max<a[i])
		{
			max=a[i];
		}
	}
	printf("maxinum value of array\n");
       return max;
}




//find the key elemet which you wnat to search
int search(int *a)
{
	int key,size,i;
	printf("enetr the element for search\n");
	scanf("%d",&key);

	for(i=0;i<size;i++)
	{
		if(a[i]==key)
		{
			printf("%d is search at loctaion %d\n",key,i);
			break;
		}
		}
		if(i==size)
		{
		printf("element not found\n");
		}
	


}
//find the duplicate element in array 
void duplicate(int *a)
{
	int count=0,key,i,j;

	for(i=0;i<size;i++)
	{
		for(j=j+1;j<size;j++)
		{
			if(a[i]==a[j])
			{
				count++;
				key=a[j];
			}
		}
	}

	if(count==0)
	{
		printf("no duplicate element\n");
	}
	else
	{
		printf("duplicate element is %d",key);
	}



}
