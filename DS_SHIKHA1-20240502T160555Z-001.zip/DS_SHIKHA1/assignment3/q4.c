/*Q4. Write a C/C++ program to implement single linked list to store
Student Information ( StudentName and StudentPRN).
Implement below metioned functions. Apply all required condition
check & validation like list empty or not, while inserting/deleting by
position validate the position.
a)insertAtEnd b) insertAtBeg c) insertAtPos d) displayList
e)listNodeCount f) deleteFromEnd g) deleteFromBeg
h)deleteFromPos i) deleteByElement j) reverseDisplay
k)freeAllNode
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct node{
	int prn;
	char name[10];
	struct node *next;

};
void insertatend(char *a,int ele);
void insertatbeg(int ele,char *a);
void display();
void deletefrombeg();
void deletefromend();
void listnodeCount();
void deleteElement();
void reverseDisplay();
void freeallNode();
void reverseList();
void sortList();


struct node *head;
int main()

{
	int ele,pos,choice;
	char name1[10];
	head = NULL;
	while(1)
	{
		printf("\n\nEnter your choice\n \n\n1->insert at begin\n2->insert at end \n3->display\n4->delete from beg\n5->delete from end\n6->listnodeCount\n7->deleteElement\n8->reverseDisplay\n9->freeallNode\n10->reverseList\n11->sortList\n0-> exit\n\n");
	        scanf("%d",&choice);
	
		switch(choice)
		{
			case 1:
				printf("enter prn\n");
				scanf("%d",&ele);
				printf("enetr the name\n");
				scanf("%s",name1);
				insertatbeg(ele,name1);
				break;
			case 2:
				printf("enter prn\n");
				scanf("%d",&ele);
				printf("enetr the name\n");
				scanf("%s",name1);
				insertatend(name1,ele);
				break;
			case 3:
				display();
				break;
			case 4:
				deletefrombeg();
				break;
			
			case 5:
				deletefromend();
				break;
			case 6:
				listnodeCount();
				break;

			case 7:
				deleteElement();
				break;

			case 8:
				reverseDisplay();
				break;
			case 9:
				freeallNode();
				break;

			case 10:
				reverseList();
				break;
			case 11:
				sortList();
				break;

			case 0:
				exit(0);
			default:
				printf("wrong choice:\n");
				break;
			}
				
		
		}

}
void insertatend(char *a,int ele)
{
	struct node *temp;
	struct node *t1;
	t1=head;

	temp=(struct node *)malloc(sizeof(struct node));
	temp->prn = ele;
	strcpy(temp->name,a);

	temp->next= NULL;

	if(head==NULL)
	{
		head = temp;
	}
	else
	{
		while(t1->next!=NULL)
		{
			t1=t1->next;
		}
		t1->next = temp;
	}

}
void insertatbeg(int ele,char *a)
{
	struct node *temp;
	temp =(struct node *)malloc(sizeof(struct node));
	temp->prn=ele;
	strcpy(temp->name,a);
	temp->next=NULL;
	if(head==NULL)
	{
		head=temp;
	}
	else
	{
		temp->next=head;
		head = temp;	
	
	}


}

void display()
{
	struct node *t1=head;
	if(head==NULL){
	printf("Linked list empty\n");
	}
	else
	{while(t1!=NULL)
	{
		printf("\n\tPRN-> %d\n\t",t1->prn);
		printf("\n\tNAME-> %s\n\t",t1->name);
		t1= t1->next;
		

	}
	}

}

void deletefrombeg()
{
	struct node *t1;
	t1=head;
	head = t1->next;
	free(t1);

}
void deletefromend()
{
	struct node *t1,*t2;
	t1=head;
	if(head->next==NULL){
	 head=NULL;
	}
	while(t1->next!=NULL){
		t2=t1;
		t1=t1->next;
	}
	free(t1);
	t2->next=NULL;

}


void listnodeCount()
{
	struct node *t1=head;
	int count=0;
	while(t1!=NULL)
	{
		t1=t1->next;
		count++;
	}
	printf("count =%d",count);
}

void deleteElement()
{
	struct node *t1=head;
	int pos,count=1;
	struct node *temp;
	printf("enetr the position\n");
	scanf("%d",&pos);

	while(t1!=NULL)
	{
		count++;
		temp=t1;
		t1=t1->next;
		if(pos==count)
		{
			temp->next=t1->next;
		}
	}
	free(t1);
}



void reverseDisplay()
{   struct node *t1=head;    
    if(t1==NULL)
       return;
	
	reverseDisplay();
	printf("\n\tprn==%d\n\t",t1->prn);
	printf("\n\tname=%s\n\t",t1->name);
}

void freeallNode()
{

	struct node *t1=head;
	while(t1->next!=NULL)
	{
	deletefromend();
	}
	deletefromend();
}

void reverseList()
{
	struct node *prev;
	struct node *next;
	struct node *current;
	current=head;
	prev=NULL;
	while(current!=NULL)
	{
		next=current->next;
		current->next=prev;
		prev=current;
		current=next;
	}
	head=prev;

}

void sortList()
{   
   struct node *t1, *t2;
  int temp;


  t1 = head;


  while (t1->next != NULL)
	{
	  t2 = t1->next;
	  while (t2 != NULL)
		{

		  if (t1->prn >t2->prn)
			{
			  temp = t1->prn;
			  t1->prn=t2->prn;
			  t2->prn = temp;

			}
		  t2 = t2->next;
		}
	  t1 = t1->next;


	}
  
}



