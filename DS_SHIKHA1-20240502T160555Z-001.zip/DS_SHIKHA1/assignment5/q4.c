#include<stdio.h>
#include<stdlib.h>

struct prique
{
	int data;
	int pri;
}pq[5];


int isempty();
int isfull();
int getpri();
int insert(int,int);
int delete();
void display();

int rear=-1;
int n=5;
int main()
{
	int choice,ele,p,del;
	while(1)
	{
		printf("1-insert\n2-getpri\n3-delete\n4-display\n5:exit\n");
		printf("enetr the choice\n\t");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1:
				if(isfull())
				{
					printf("priority is full\n");
				}
				else
				{
					printf("enetr the element and priority\n");
					scanf("%d%d",&ele,&p);
					insert(ele,p);
				}
				break;
			case 2:
				if(isempty())
				{
					printf("priority queue is empty\n");
				}
				else
				{
					p=getpri();
					printf("\n higthest priority is %d\n",p);
				}
				break;
			case 3:
				if(isempty())
                                {
                                        printf("priority queue is empty\n");
                                
				}
				else
				{
					del=delete();
					printf(" delete element is %d\n",del);
				}
				break;

			case 4:
				if(isempty())
                                {
                                        printf("priority queue is empty\n");
                                
				}
				else
				{
					display();
				}
				break;
				case 5:
				exit(0);
				default :
				printf("wrong choice\n\t");
		}


				               


	}
}


	
int isempty()
{
	if(rear==-1)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
int isfull()
{
	if(rear==n-1)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

int insert(int ele,int p)
{
	rear=rear+1;
	pq[rear].data=ele;
	pq[rear].pri=p;
}


int getpri()
{
	int p=-1,i;
	if(!isempty())
	{
		for(i=0;i<=rear;i++)
		{
			if(pq[i].pri>p)
			{
				p=pq[i].pri;
			}
		}
	}
	return p;
}


int delete()
{
	int i,j,p,ele;
	p=getpri();

	for(i=0;i<=rear;i++)
	{
		if(pq[i].pri==p)
		{
			ele=pq[i].pri;
			break;
		}
	}
	if(i<rear)
	{
		for(j=i;j<rear;j++)
		{
			pq[j].data=pq[j+i].data;
			pq[j].pri=pq[j+1].pri;//shift to left
		}
		rear=rear-1;
		return ele;
	}
}


void display()
{
	int i;
	printf("prique============\n");
	for(i=0;i<=rear;i++)
	{
		printf("element=%d ||| priority=%d\n",pq[i].data,pq[i].pri);
	}
}




