/*Q1. Write a C/C++ program to implement single circular linked list
with below metioned functionality.
a) insertAtEnd b) insertAtBeg c) insertAtPos
d) display e) listNodeCount f) deleteFromEnd
g) deleteFromBeg h) deleteFromPos*/
#include<stdio.h>
#include<stdlib.h>
#include<stdio_ext.h>
struct node
{
  int data;
  struct node *next;
};

void insert_end (struct node **, int);
void display (struct node *);
void reverse (struct node **);
void search (struct node *);
void duplicate (struct node *);
void delete_position (struct node **, int);
void delete_beg (struct node **);
void reversed_display (struct node *, struct node *);
void sortedList (struct node **);
void count_node (struct node **);
int valid (struct node **);
void insert_beg (struct node **, int);
void insert_pos (struct node **, int, int);
int main ()
{
  struct node *head;

  head = NULL;
  int ele, ch, pos;
  while (1)
	{

	  printf
		("\n\t0:exit\n\t1:INSERT AT END\n\t2:DISPLAY LINKEDLIST\n\t3:Reverse Linked List\n\t4:search element \n\t5:DUPLICATE ELEMENT");
	  printf
		("\n\t 6:Deleted at position\n\t7:delete at begin\n\t8:reversed display\n\t9:sorting linked list\n\t10: count node\n\t11:insert at begin\n\t12:insert at position\n\t");
	  printf ("enter the above choice\n");
	  scanf ("%d", &ch);

	  switch (ch)
		{
		case 1:
		  
		  ele = valid (&head);
		  
		  insert_end (&head, ele);
		 
		 break;
		case 2:

		  display (head);
		  
		  break;
		
		case 3:
		  
		  reverse (&head);
		 
		  break;
		
		case 4:
		  
		  search (head);
		  
		  break;
		case 5:
		  
		  duplicate (head);
		  
		  break;

		case 6:
		  
		  printf ("enter position\n");
		  
		  scanf ("%d", &pos);
		  
		  delete_position (&head, pos);
		  
		  break;

		case 7:

		  delete_beg (&head);

		  break;
		case 8:

		  reversed_display (head, head);
		  
		  break;
		case 9:
		  sortedList (&head);
		  
		  break;
		case 10:
		  count_node (&head);
		  break;
		case 11:
		  ele = valid (&head);
		  
		  insert_beg (&head, ele);
		  
		  break;
		
		case 12:
		  
		 
		  printf ("enter position\n");
		  
		  scanf ("%d", &pos);
		  
		  ele = valid (&head);
		  
		  insert_pos (&head, ele, pos);
		 
		  break;
		case 0:

		  exit (0);

		default:

		  printf ("WRONG CHOICE\n");

		}
	}
}

void insert_end (struct node **h, int ele)
{

  struct node *t1, *temp;
  temp = (struct node *) malloc (sizeof (struct node));

  if (temp == NULL)
	{
	  printf ("invalid memory allocation\n");
	  exit (0);
	}



  temp->data = ele;
  temp->next = NULL;

  t1 = *h;

  if (*h == NULL)
	{
	  *h = temp;
	  temp->next = *h;
	}
  else
	{
	  while (t1->next != *h)
		{
		  t1 = t1->next;
		}

	  temp->next = *h;
	  t1->next = temp;
	}
}

void display (struct node *h)
{
  struct node *t = h;
  if (t == NULL)
	{
	  printf ("No element found");
	}
  else
	{
	  printf (">>%d", t->data);
	  t = t->next;

	  while (t != h)
		{
		  printf (">>%d", t->data);
		  t = t->next;
		}

	}
}


void reverse (struct node **h)
{
  struct node *t, *curr, *prev;

  curr = *h;
  prev = *h;
  if (*h == NULL)
	{
	  printf ("Linked list is empty.!!! Cannot reverse!!!!");
	}
  else
	{
	  curr = curr->next;

	  while (curr != *h)
		{
		  t = curr->next;
		  curr->next = prev;
		  prev = curr;
		  curr = t;
		}
	  (*h)->next = prev;
	  *h = prev;
	  printf ("\n Linked list reversed.  :)\n");
	  display (*h);
	}

}


void search (struct node *h)
{
  struct node *t = h;
  int s_ele;
  printf ("Enter the element to search:\n");
  scanf ("%d", &s_ele);
  if (t == NULL)
	{
	  printf ("Linked list Empty");
	}
  else
	{
	  if (s_ele == t->data)
		{
		  printf ("Element found \n");
		  return;
		}
	  t = t->next;

	  while (t != h)
		{

		  if (s_ele == t->data)
			{
			  printf ("Element found \n");
			  return;
			}
		  t = t->next;
		}
	  printf ("No element found\n");
	}
}

void duplicate (struct node *h)
{
  struct node *t1 = h;
  struct node *t2 = h;
  if (t1 == NULL)
	{
	  printf ("linked list Empty\n");
	}
  else
	{

	  while (t1->next != h)
		{
		  t2 = t1->next;
		  while (t2 != h)
			{
			  if (t1->data == t2->data)
				{
				  printf ("duplicate found...!!!!!\n");
				  return;
				}
			  t2 = t2->next;
			}
		  t1 = t1->next;
		}
	  printf ("DUPLICATE ELEMENT NOT FOUND\n");

	}
}



void delete_position (struct node **t, int pos)
{
  struct node *temp = *t;
  struct node *t2;
  int i = 1;
  if (temp == NULL)
	{
	  printf ("you cannot delete element\n");
	}


  else
	{
	  if (pos == 1)
		{
		  delete_beg (t);
		}
	  else
		{
		  while (i < pos)
			{
			  t2 = temp;

			  temp = temp->next;

			  i++;

			}

		  t2->next = temp->next;

		  free (temp);
		}
	}



}




void delete_beg (struct node **h)
{
  struct node *t1;
  struct node *t2;


  t1 = *h;
  t2 = *h;

  if (*h == NULL)
	{
	  printf ("Empty Linked list. Cannot delete.!!");
	  return;
	}

  if (t1->next == *h)
	{
	  *h = NULL;
	}

  else
	{
	  while (t1->next != *h)
		{
		  t1 = t1->next;
		}

	  t1->next = (*h)->next;
	  *h = (*h)->next;
	}

  free (t2);



}


void reversed_display (struct node *p, struct node *t1)
{
  if (t1->next == p)
	{
	  printf ("%d", t1->data);
	  return;
	}
  reversed_display (p, t1->next);
  printf ("<<<%d", t1->data);
}




void sortedList (struct node **p)
{
  struct node *t1, *t2;
  int temp;


  t1 = *p;


  while (t1->next != *p)
	{
	  t2 = t1->next;
	  while (t2 != *p)
		{

		  if (t1->data > t2->data)
			{
			  temp = t1->data;
			  t1->data = t2->data;
			  t2->data = temp;

			}
		  t2 = t2->next;
		}
	  t1 = t1->next;


	}

}

void count_node (struct node **p)
{
  int count = 1;
  struct node *t1 = *p;

  if (*p == NULL)
	{
	  printf ("linked is empty !!!\n");
	}
  else
	{
	  while (t1->next != *p)
		{
		  count++;
		  t1 = t1->next;
		}
	  printf ("total number of node is %d\n", count);
	}
}

int valid (struct node **p)
{
  int value, flag = 1;
  struct node *t1;

  while (flag)
	{
	  t1 = *p;
	  flag = 0;
	  printf ("Enter the the element:\n");
	  __fpurge (stdin);
	  scanf ("%d", &value);
	  if (*p == NULL)
		{
		  break;
		}
	  while (t1->next != *p)
		{
		  if (t1->data == value)
			{
			  printf ("Duplicate Element.!! Try again..\n");
			  flag = 1;
			}
		  t1 = t1->next;
		}
	  if (t1->data == value)
		{
		  printf ("Duplicate Element.!! Try again..\n");
		  flag = 1;

		}
	}
  return value;
}

void insert_beg (struct node **p, int ele)
{

  struct node *t1, *temp;
  t1 = *p;

  temp = (struct node *) malloc (sizeof (struct node));
  temp->data = ele;
  temp->next = NULL;


  t1 = t1->next;

  if (*p == NULL)
	{
	  temp->next = *p;
	  *p = temp;

	}
  else
	{

	  temp->next = *p;

	  while (t1->next != *p)
		{
		  t1 = t1->next;

		}

	  t1->next = temp;
	  *p = temp;

	}
}

void insert_pos (struct node **p, int ele, int pos)
{

  struct node *t1, *temp;


  temp = (struct node *) malloc (sizeof (struct node));
  temp->data = ele;
  temp->next = NULL;

  t1 = *p;

  if (*p == NULL)
	{
	  *p = temp;
	  temp->next = *p;
	}

  else
	{
	  if (pos == 1)
		{
		  insert_beg (p, ele);
		  return;
		}

	  int i = 1;
	  while (i < pos - 1)
		{

		  t1 = t1->next;
		  i++;
		}


	  temp->next = t1->next;

	  t1->next = temp;
	}


}

